var myaddress = "your public wallet address" // your public wallet address
var myprivatekey = "your privatekey of the wallet address" // the privatekey of the wallet address
var myseed = "your wallet seed" //only give this if your privatekey is stored in a wallet without accessibility example (hardwarewallets)
var networks = "1" //1 = ETH , 2 = BNB , 3 = Polygon 
var maxspend = "0.5" // max amount to uses for Yield farming from the address given 
